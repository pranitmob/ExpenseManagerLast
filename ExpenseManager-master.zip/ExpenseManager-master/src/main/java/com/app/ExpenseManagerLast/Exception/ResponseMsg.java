package com.app.ExpenseManagerLast.Exception;

public class ResponseMsg {
	
	String responseMsg;

	public ResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	
	
	
}
