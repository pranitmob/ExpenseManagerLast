package com.app.ExpenseManagerLast.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class UserControllerTest {

	@Test
	public void testRegisterUser() throws Exception {
		fail("Not yet implemented");
	}

	@Test
	public void testLoginUser() {
		fail("Not yet implemented");

	}

}
