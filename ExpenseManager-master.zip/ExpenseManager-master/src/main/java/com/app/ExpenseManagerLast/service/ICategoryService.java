package com.app.ExpenseManagerLast.service;

import java.util.List;

public interface ICategoryService {

	public List<Object> getAllCategories();

}
