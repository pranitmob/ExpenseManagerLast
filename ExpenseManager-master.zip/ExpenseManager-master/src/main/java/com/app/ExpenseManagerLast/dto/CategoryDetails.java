package com.app.ExpenseManagerLast.dto;

public class CategoryDetails {
	
	private String category;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
}
