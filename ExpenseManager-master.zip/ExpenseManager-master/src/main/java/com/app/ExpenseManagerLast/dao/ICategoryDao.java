package com.app.ExpenseManagerLast.dao;

import java.util.List;

public interface ICategoryDao {
	
	List<Object> getAllCategories();

}
